/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Softmax.cpp
 * Author: ltsach
 * 
 * Created on August 25, 2024, 2:46 PM
 */

#include "layer/Softmax.h"
#include "ann/functions.h"
#include "sformat/fmt_lib.h"
#include <filesystem> //require C++17
namespace fs = std::filesystem;

Softmax::Softmax(int axis, string name): m_nAxis(axis) {
    if(trim(name).size() != 0) m_sName = name;
    else m_sName = "Softmax_" + to_string(++m_unLayer_idx);
}

Softmax::Softmax(const Softmax& orig) {
}

Softmax::~Softmax() {
}

xt::xarray<double> Softmax::forward(xt::xarray<double> X) {
    cout<<"checkpoint7"<<endl;

    //YOUR CODE IS HERE
    // if (m_nAxis < -static_cast<int>(X.dimension()) || m_nAxis >= static_cast<int>(X.dimension())) {
    //     std::cerr << "X dimension: " << X.dimension() << ", axis provided: " << m_nAxis << std::endl;
    //     throw std::invalid_argument("Invalid axis for softmax.");
    // }

    int axis = (m_nAxis < 0) ? X.dimension() + m_nAxis : m_nAxis;
    cout<<"checkpointY"<<endl;


    // Tính softmax theo từng hàng của batch
    auto X_max = xt::amax(X, {axis}, xt::keep_dims);  // Tránh overflow
    auto exp_X = xt::exp(X);
    auto sum_exp_X = xt::sum(exp_X, {axis}, xt::keep_dims);

    m_aCached_Y = exp_X / sum_exp_X;  // Lưu trữ kết quả softmax cho backward
    cout<<"checkpointX"<<endl;

    return m_aCached_Y;

    // if (m_nAxis < -static_cast<int>(X.dimension()) || m_nAxis >= static_cast<int>(X.dimension())) {
    //     throw std::invalid_argument("Invalid axis for softmax.");
    // }

    // // Convert negative axis to positive
    // int axis = (m_nAxis < 0) ? X.dimension() + m_nAxis : m_nAxis;

    // // Compute max for numerical stability
    // auto X_max = xt::amax(X, {static_cast<std::size_t>(axis)}, xt::keep_dims);
    
    // // Compute exp(x - max(x))
    // auto exp_X = xt::exp(X - X_max);
    
    // // Compute sum of exponentials
    // auto sum_exp = xt::sum(exp_X, {static_cast<std::size_t>(axis)}, xt::keep_dims);
    
    // // Compute softmax
    // m_aCached_Y = exp_X / sum_exp;
    
    // return m_aCached_Y;



}
xt::xarray<double> Softmax::backward(xt::xarray<double> DY) {
    //YOUR CODE IS HERE
    xt::xarray<double> DZ = xt::zeros_like(DY);

    int axis = (m_nAxis < 0) ? DY.dimension() + m_nAxis : m_nAxis;
        cout<<"checkpoint5"<<endl;

        // Duyệt qua từng hàng dữ liệu trong batch
    if(DY.dimension() > 1){
        
        for (std::size_t i = 0; i < DY.shape()[0]; ++i) {  
            auto Y = xt::view(m_aCached_Y, i, xt::all());  // Softmax đầu ra
            auto DY_batch = xt::view(DY, i, xt::all());    // Gradient đầu vào

            // Tạo ma trận Jacobian cho softmax
            xt::xarray<double> diag_Y = xt::diag(Y);
            xt::xarray<double> outer_Y = xt::linalg::outer(Y, xt::transpose(Y));
            xt::xarray<double> jacobian = diag_Y - outer_Y;

            // Tính toán gradient
            xt::view(DZ, i, xt::all()) = xt::linalg::tensordot(jacobian, DY_batch, {1});
        }
            cout<<"checkpoint4"<<endl;
    }
    else {
        auto Y = m_aCached_Y;
        auto DY_batch = DY;

        // Tạo ma trận Jacobian cho softmax
        xt::xarray<double> diag_Y = xt::diag(Y);
        xt::xarray<double> outer_Y = xt::linalg::outer(Y, xt::transpose(Y));
        xt::xarray<double> jacobian = diag_Y - outer_Y;

        // Tính toán gradient
        DZ = xt::linalg::tensordot(jacobian, DY_batch, {1});
    }

    return DZ;


}

string Softmax::get_desc(){
    string desc = fmt::format("{:<10s}, {:<15s}: {:4d}",
                    "Softmax", this->getname(), m_nAxis);
    return desc;
}
